Latest version archived in Google Drive:
goo.gl/rJk39G
